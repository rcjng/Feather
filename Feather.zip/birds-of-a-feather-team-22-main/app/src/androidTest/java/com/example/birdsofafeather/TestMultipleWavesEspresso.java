package com.example.birdsofafeather;


import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.contrib.RecyclerViewActions.actionOnItemAtPosition;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anything;
import static org.hamcrest.Matchers.is;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import androidx.test.espresso.DataInteraction;
import androidx.test.espresso.ViewInteraction;
import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class TestMultipleWavesEspresso {

    @Rule
    public ActivityTestRule<NameActivity> mActivityTestRule = new ActivityTestRule<>(NameActivity.class);

    @Test
    public void testMultipleWavesEspresso() {
        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.confirm_button), withText("Confirm"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                0),
                        isDisplayed()));
        appCompatButton.perform(click());

        ViewInteraction appCompatEditText = onView(
                allOf(withId(R.id.photo_view),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText.perform(replaceText("testphoto"), closeSoftKeyboard());

        ViewInteraction appCompatButton2 = onView(
                allOf(withId(R.id.submit_button), withText("Submit"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                0),
                        isDisplayed()));
        appCompatButton2.perform(click());

        ViewInteraction appCompatEditText2 = onView(
                allOf(withId(R.id.subject_view),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                10),
                        isDisplayed()));
        appCompatEditText2.perform(replaceText("CSE"), closeSoftKeyboard());

        ViewInteraction appCompatEditText3 = onView(
                allOf(withId(R.id.number_view),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                5),
                        isDisplayed()));
        appCompatEditText3.perform(replaceText("110"), closeSoftKeyboard());

        ViewInteraction appCompatSpinner = onView(
                allOf(withId(R.id.quarter_spinner),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                7),
                        isDisplayed()));
        appCompatSpinner.perform(click());

        DataInteraction appCompatCheckedTextView = onData(anything())
                .inAdapterView(childAtPosition(
                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
                        0))
                .atPosition(2);
        appCompatCheckedTextView.perform(click());

        ViewInteraction appCompatSpinner2 = onView(
                allOf(withId(R.id.year_spinner),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                9),
                        isDisplayed()));
        appCompatSpinner2.perform(click());

        DataInteraction appCompatCheckedTextView2 = onData(anything())
                .inAdapterView(childAtPosition(
                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
                        0))
                .atPosition(1);
        appCompatCheckedTextView2.perform(click());

        ViewInteraction appCompatSpinner3 = onView(
                allOf(withId(R.id.class_size_spinner),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                2),
                        isDisplayed()));
        appCompatSpinner3.perform(click());

        DataInteraction appCompatCheckedTextView3 = onData(anything())
                .inAdapterView(childAtPosition(
                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
                        0))
                .atPosition(4);
        appCompatCheckedTextView3.perform(click());

        ViewInteraction appCompatButton3 = onView(
                allOf(withId(R.id.enter_button), withText("Enter"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatButton3.perform(click());

        ViewInteraction appCompatEditText4 = onView(
                allOf(withId(R.id.number_view), withText("110"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                5),
                        isDisplayed()));
        appCompatEditText4.perform(click());

        ViewInteraction appCompatEditText5 = onView(
                allOf(withId(R.id.number_view), withText("110"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                5),
                        isDisplayed()));
        appCompatEditText5.perform(replaceText("105"));

        ViewInteraction appCompatEditText6 = onView(
                allOf(withId(R.id.number_view), withText("105"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                5),
                        isDisplayed()));
        appCompatEditText6.perform(closeSoftKeyboard());

        ViewInteraction appCompatButton4 = onView(
                allOf(withId(R.id.enter_button), withText("Enter"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatButton4.perform(click());

        ViewInteraction appCompatButton5 = onView(
                allOf(withId(R.id.done_button), withText("Done"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                4),
                        isDisplayed()));
        appCompatButton5.perform(click());

        ViewInteraction appCompatButton6 = onView(
                allOf(withId(R.id.nearby_button), withText("Nearby"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatButton6.perform(click());

        ViewInteraction appCompatEditText7 = onView(
                allOf(withId(R.id.mocking_input_view),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText7.perform(replaceText("1212ttr-454fg-sdf09,,,,\nBill,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large"), closeSoftKeyboard());

        ViewInteraction appCompatEditText8 = onView(
                allOf(withId(R.id.mocking_input_view), withText("1212ttr-454fg-sdf09,,,,\nBill,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText8.perform(click());

        ViewInteraction appCompatEditText9 = onView(
                allOf(withId(R.id.mocking_input_view), withText("1212ttr-454fg-sdf09,,,,\nBill,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText9.perform(replaceText("1212ttr-454fg-sdf09,,,,\nBill,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\n"));

        ViewInteraction appCompatEditText10 = onView(
                allOf(withId(R.id.mocking_input_view), withText("1212ttr-454fg-sdf09,,,,\nBill,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText10.perform(closeSoftKeyboard());

        ViewInteraction materialTextView = onView(
                allOf(withId(R.id.self_profile_id_view), withText("e25c4970-c706-4e7c-81f1-dee51ee0e65c"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                3),
                        isDisplayed()));
        materialTextView.perform(click());

        ViewInteraction appCompatEditText11 = onView(
                allOf(withId(R.id.mocking_input_view), withText("1212ttr-454fg-sdf09,,,,\nBill,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText11.perform(replaceText("1212ttr-454fg-sdf09,,,,\nBill,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,"));

        ViewInteraction appCompatEditText12 = onView(
                allOf(withId(R.id.mocking_input_view), withText("1212ttr-454fg-sdf09,,,,\nBill,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText12.perform(closeSoftKeyboard());

        ViewInteraction appCompatButton7 = onView(
                allOf(withId(R.id.mock_enter_button), withText("Enter"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                0),
                        isDisplayed()));
        appCompatButton7.perform(click());

        ViewInteraction appCompatEditText13 = onView(
                allOf(withId(R.id.mocking_input_view),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText13.perform(click());

        ViewInteraction appCompatEditText14 = onView(
                allOf(withId(R.id.mocking_input_view),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText14.perform(replaceText("asd343-34534sdgdsf,,,,\nCarl,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\n"), closeSoftKeyboard());

        ViewInteraction materialTextView2 = onView(
                allOf(withId(R.id.self_profile_id_view), withText("e25c4970-c706-4e7c-81f1-dee51ee0e65c"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                3),
                        isDisplayed()));
        materialTextView2.perform(click());

        ViewInteraction appCompatEditText15 = onView(
                allOf(withId(R.id.mocking_input_view), withText("asd343-34534sdgdsf,,,,\nCarl,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText15.perform(replaceText("asd343-34534sdgdsf,,,,\nCarl,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,"));

        ViewInteraction appCompatEditText16 = onView(
                allOf(withId(R.id.mocking_input_view), withText("asd343-34534sdgdsf,,,,\nCarl,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText16.perform(closeSoftKeyboard());

        ViewInteraction appCompatEditText17 = onView(
                allOf(withId(R.id.mocking_input_view), withText("asd343-34534sdgdsf,,,,\nCarl,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText17.perform(click());

        ViewInteraction appCompatEditText18 = onView(
                allOf(withId(R.id.mocking_input_view), withText("asd343-34534sdgdsf,,,,\nCarl,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText18.perform(replaceText("asd343-34534sdgdsf,,,,\nCarl,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"));

        ViewInteraction appCompatEditText19 = onView(
                allOf(withId(R.id.mocking_input_view), withText("asd343-34534sdgdsf,,,,\nCarl,,,,\ntestphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText19.perform(closeSoftKeyboard());

        ViewInteraction appCompatButton8 = onView(
                allOf(withId(R.id.mock_enter_button), withText("Enter"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                0),
                        isDisplayed()));
        appCompatButton8.perform(click());

        ViewInteraction appCompatEditText20 = onView(
                allOf(withId(R.id.mocking_input_view),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText20.perform(replaceText("sdf8808345-345345,,,,\nDave,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"), closeSoftKeyboard());

        ViewInteraction appCompatButton9 = onView(
                allOf(withId(R.id.mock_enter_button), withText("Enter"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                0),
                        isDisplayed()));
        appCompatButton9.perform(click());

        ViewInteraction appCompatEditText21 = onView(
                allOf(withId(R.id.mocking_input_view),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText21.perform(click());

        ViewInteraction appCompatEditText22 = onView(
                allOf(withId(R.id.mocking_input_view),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText22.perform(replaceText("sdf8808345-345345,,,,\nDave,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"), closeSoftKeyboard());

        ViewInteraction appCompatEditText23 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf8808345-345345,,,,\nDave,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText23.perform(click());

        ViewInteraction appCompatEditText24 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf8808345-345345,,,,\nDave,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText24.perform(replaceText("sdf88083304-345345,,,,\nDave,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"));

        ViewInteraction appCompatEditText25 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf88083304-345345,,,,\nDave,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText25.perform(closeSoftKeyboard());

        ViewInteraction appCompatEditText26 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf88083304-345345,,,,\nDave,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText26.perform(click());

        ViewInteraction appCompatEditText27 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf88083304-345345,,,,\nDave,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText27.perform(replaceText("sdf88083304-345345,,,,\nPaul,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"));

        ViewInteraction appCompatEditText28 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf88083304-345345,,,,\nPaul,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText28.perform(closeSoftKeyboard());

        ViewInteraction appCompatEditText29 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf88083304-345345,,,,\nPaul,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText29.perform(click());

        ViewInteraction appCompatEditText30 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf88083304-345345,,,,\nPaul,,,,\ntesphoto,,,,\n2022,WI,CSE,105,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText30.perform(replaceText("sdf88083304-345345,,,,\nPaul,,,,\ntesphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"));

        ViewInteraction appCompatEditText31 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf88083304-345345,,,,\nPaul,,,,\ntesphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText31.perform(closeSoftKeyboard());

        ViewInteraction appCompatEditText32 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf88083304-345345,,,,\nPaul,,,,\ntesphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText32.perform(click());

        ViewInteraction appCompatEditText33 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf88083304-345345,,,,\nPaul,,,,\ntesphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText33.perform(replaceText("sdf88083304-345345,,,,\nPaul,,,,\ntesphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n\n"));

        ViewInteraction appCompatEditText34 = onView(
                allOf(withId(R.id.mocking_input_view), withText("sdf88083304-345345,,,,\nPaul,,,,\ntesphoto,,,,\n2022,WI,CSE,110,Large\ne25c4970-c706-4e7c-81f1-dee51ee0e65c,wave,,,\n\n"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                1),
                        isDisplayed()));
        appCompatEditText34.perform(closeSoftKeyboard());

        ViewInteraction appCompatButton10 = onView(
                allOf(withId(R.id.mock_enter_button), withText("Enter"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                0),
                        isDisplayed()));
        appCompatButton10.perform(click());

        ViewInteraction appCompatButton11 = onView(
                allOf(withId(R.id.start_button), withText("Start"),
                        childAtPosition(
                                childAtPosition(
                                        withId(android.R.id.content),
                                        0),
                                2),
                        isDisplayed()));
        appCompatButton11.perform(click());

        ViewInteraction recyclerView = onView(
                allOf(withId(R.id.session_recycler_view),
                        childAtPosition(
                                withId(R.id.classes_layout),
                                0)));
        recyclerView.perform(actionOnItemAtPosition(0, click()));
        onView(withId(R.id.profile_wave)).check(matches(isDisplayed()));
    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
